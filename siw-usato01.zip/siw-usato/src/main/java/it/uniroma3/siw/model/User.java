package it.uniroma3.siw.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "Utenti")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@NotBlank
	private String nome;
	@NotBlank
	private String cognome;
	@Email
	private String mail;
	@OneToMany(mappedBy="venditore")
	private List<Articolo>articoliVenduti;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public List<Articolo> getArticoliVenduti() {
		return articoliVenduti;
	}
	public void setArticoliVenduti(List<Articolo> articoliVenduti) {
		this.articoliVenduti = articoliVenduti;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	@Override
	public boolean equals(Object o) {
		User u=(User)o;
		return this.getNome().equals(u.getNome()) && this.getCognome().equals(u.getCognome());
	}
	@Override
	public int hashCode() {
		return this.getNome().hashCode()+this.getCognome().hashCode();
	}

}
