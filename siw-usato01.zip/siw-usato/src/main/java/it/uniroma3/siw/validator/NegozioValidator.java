package it.uniroma3.siw.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Negozio;
import it.uniroma3.siw.repository.NegozioRepository;

@Component
public class NegozioValidator implements Validator {

	@Autowired
	public NegozioRepository negozioRepository;


	public void validate(Object o,Errors errors) {
		Negozio negozio=(Negozio)o;
		if(negozio.getId()==0) {
			if(negozio.getIndirizzo()!=null && negozioRepository.existsByIndirizzo(negozio.getIndirizzo())) {
				errors.reject("negozio.duplicate");
			}
		}

	}

	public boolean supports(Class<?> aClass) {
		return Negozio.class.equals(aClass);
	}

}
