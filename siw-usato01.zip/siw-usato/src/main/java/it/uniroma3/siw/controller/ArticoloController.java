package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.uniroma3.siw.model.Articolo;
import it.uniroma3.siw.repository.ArticoloRepository;
import it.uniroma3.siw.repository.NegozioRepository;
import it.uniroma3.siw.validator.ArticoloValidator;
import jakarta.validation.Valid;

@Controller
public class ArticoloController {

	@Autowired ArticoloRepository articoloRepository;
	@Autowired ArticoloValidator articoloValidator;
	@Autowired GlobalController globalController;
	@Autowired NegozioRepository negozioRepository;
	
	@GetMapping("/index")
	public String index() {
		return "index.html";
	}
	@GetMapping("/articoli")
	public String tuttiArticoliInVendita(Model model) {
		model.addAttribute("articoliInVendita", this.articoloRepository.findByPrenotatoFalse());
		return "articoliInVendita.html";
	}
	
	@GetMapping("/admin/aggiungiNuovoArticolo")
	public String aggiungiNuovoArticolo(Model model) {
		model.addAttribute("negozi",this.negozioRepository.findAll());
		model.addAttribute("articolo", new Articolo());
		return "aggiungiNuovoArticolo.html";
	}
	@GetMapping("/admin/modificaArticolo/{id}")
	public String modificaArticolo(@PathVariable("id")Long id,Model model) {
		model.addAttribute("negozi",this.negozioRepository.findAll());
		model.addAttribute("articolo", this.articoloRepository.findById(id).get());
		return "aggiungiNuovoArticolo.html";
	}
	
	@PostMapping("/admin/articolo")
	public String nuovoArticolo(@Valid@ModelAttribute("articolo") Articolo articolo,BindingResult bindingResult,
			Model model) {
		this.articoloValidator.validate(articolo, bindingResult);
		if(!bindingResult.hasErrors()) {
			this.articoloRepository.save(articolo);
			model.addAttribute("articolo", articolo);
			return "articolo.html";			
		}
		else {
			model.addAttribute("negozi",this.negozioRepository.findAll());
			return "aggiungiNuovoArticolo.html";
		}
	}
	@GetMapping("/articoli/{id}")
	public String singoloArticolo(@PathVariable("id")Long id,Model model) {
		model.addAttribute("articolo", this.articoloRepository.findById(id).get());
		return "articolo.html";
	}
	@GetMapping("/articoli/{id}/compra")
	public String confermaPrenotazione(@PathVariable("id")Long id,Model model) {
		model.addAttribute("articolo", this.articoloRepository.findById(id).get().getId());
		model.addAttribute("descrizione", this.articoloRepository.findById(id).get().getDescrizione());
		model.addAttribute("indirizzo",this.articoloRepository.findById(id).get().getNegozio().getIndirizzo());
		return "compra.html";
	}
	
	@GetMapping("/articoli/{id}/compra/successful")
	public String aggiuntoAllePrenotazioni(@PathVariable("id")Long id) {
		Articolo daAggiungereCarrello=this.articoloRepository.findById(id).get();
		daAggiungereCarrello.setPrenotato(true);
		daAggiungereCarrello.setNelCarrelloDi(this.globalController.getUser().getUsername());
		this.articoloRepository.save(daAggiungereCarrello);		
		return "aggiuntoAllePrenotazioni.html";
	}
	@GetMapping("/prenotazioni")
	public String prenota(Model model) {
		UserDetails utenteCorrente=this.globalController.getUser();
		model.addAttribute("carrello", this.articoloRepository.findByNelCarrelloDi(utenteCorrente.getUsername()));		
		return "carrello.html";
	}
	@GetMapping("/rimuovi/{id}")
	public String rimuoviPrenotazione(@PathVariable("id")Long id,Model model) {
		Articolo daRimuovereCarrello=this.articoloRepository.findById(id).get();
		daRimuovereCarrello.setPrenotato(false);
		daRimuovereCarrello.setNelCarrelloDi(null);
		this.articoloRepository.save(daRimuovereCarrello);
		UserDetails utenteCorrente=this.globalController.getUser();
		model.addAttribute("carrello", this.articoloRepository.findByNelCarrelloDi(utenteCorrente.getUsername()));				
		return"carrello.html";
	}
	@GetMapping("/formCerca")
	public String formcerca() {
		return "formCercaArticolo.html";
	}
	@PostMapping("/cercaArticolo")
	public String cerca(Model model,@RequestParam String descrizione) {
		model.addAttribute("trovati", this.articoloRepository.findByDescrizioneContaining(descrizione));
		return "articoliTrovati.html";
	}
	
	
}
