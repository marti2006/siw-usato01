package it.uniroma3.siw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Articolo;
import it.uniroma3.siw.model.Negozio;
import it.uniroma3.siw.repository.ArticoloRepository;
import it.uniroma3.siw.repository.NegozioRepository;
import it.uniroma3.siw.validator.NegozioValidator;
import jakarta.validation.Valid;

@Controller
public class NegozioController {
	
	@Autowired NegozioValidator negozioValidator;
	@Autowired NegozioRepository negozioRepository;
	@Autowired ArticoloRepository articoloRepository;
	
	@GetMapping("/admin/aggiungiNuovoNegozio")
	public String aggiungiNuovoNegozio(Model model) {
		model.addAttribute("negozio", new Negozio());
		return "aggiungiNuovoNegozio.html";
	}
	
	@PostMapping("/admin/negozio")
	public String nuovoNegozio(@Valid@ModelAttribute("negozio") Negozio negozio,BindingResult bindingResult,
			Model model) {
		this.negozioValidator.validate(negozio, bindingResult);
		if(!bindingResult.hasErrors()) {
			this.negozioRepository.save(negozio);
			model.addAttribute("negozio", negozio);
			return "negozio.html";			
		}
		else {
			return "aggiungiNuovoNegozio.html";
		}
	}
	
	@GetMapping("/negozi")
	public String tuttiNegozi(Model model) {
		model.addAttribute("negozi", this.negozioRepository.findAll());
		return "negozi.html";
	}

	@GetMapping("/negozi/{id}")
	public String singoloNegozio(@PathVariable("id")Integer id,Model model) {
		model.addAttribute("negozio", this.negozioRepository.findById(id).get());
		List<Articolo> prenotati=this.articoloRepository.findByPrenotatoTrue();
		List<Articolo> inNegozio=this.negozioRepository.findById(id).get().getInNnegozio();
		inNegozio.removeAll(prenotati);
		model.addAttribute("inNegozio", inNegozio);
		return "negozio.html";
	}


}
