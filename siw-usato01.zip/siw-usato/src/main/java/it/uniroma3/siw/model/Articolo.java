package it.uniroma3.siw.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.*;

@Entity
public class Articolo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@Positive
	private float prezzo;
	private String urlimage;
	@NotBlank
	private String descrizione;
	private boolean prenotato=false;
	private boolean luxury;
	@ManyToOne
	private Negozio negozio;
//	private String categoria;
	@ManyToOne
//	@NotBlank
	private User venditore;
//	@ManyToOne
	private String nelCarrelloDi;

	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public float getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}
	public String getUrlimage() {
		return urlimage;
	}
	public void setUrlimage(String urlimage) {
		this.urlimage = urlimage;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public boolean isPrenotato() {
		return prenotato;
	}
	public void setPrenotato(boolean venduto) {
		this.prenotato = venduto;
	}
	public boolean isLuxury() {
		return luxury;
	}
	public void setLuxury(boolean luxury) {
		this.luxury = luxury;
	}
	public User getVenditore() {
		return venditore;
	}
	public void setVenditore(User venditore) {
		this.venditore = venditore;
	}
	public String getNelCarrelloDi() {
		return nelCarrelloDi;
	}
	public void setNelCarrelloDi(String nelCarrelloDi) {
		this.nelCarrelloDi = nelCarrelloDi;
	}
	public Negozio getNegozio() {
		return negozio;
	}
	public void setNegozio(Negozio negozio) {
		this.negozio = negozio;
	}
	@Override
	public boolean equals(Object o) {
		Articolo a=(Articolo)o;
		if(a.getDescrizione().equals(this.getDescrizione()))
			return true;
		return false;
	}
	@Override
	public int hashCode() {
		return this.getDescrizione().hashCode();
	}
}
