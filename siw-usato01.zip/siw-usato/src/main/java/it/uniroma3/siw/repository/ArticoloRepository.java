package it.uniroma3.siw.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Articolo;

public interface ArticoloRepository extends CrudRepository<Articolo, Long> {
	
	public List<Articolo> findByLuxuryTrue();
	public List<Articolo> findByPrenotatoFalse();
	public List<Articolo> findByPrezzoBetween(float min,float max);
	public boolean existsByDescrizioneAndPrezzo(String descrizione,float prezzo);
	public List<Articolo> findByNelCarrelloDi(String username);
	public List<Articolo> findByPrenotatoTrue();
	public List<Articolo> findByDescrizioneContaining(String desrizione);
}
