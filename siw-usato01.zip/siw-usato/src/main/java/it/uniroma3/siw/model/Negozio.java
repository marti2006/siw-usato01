package it.uniroma3.siw.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.*;
@Entity
public class Negozio {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
	private int id;
	@NotBlank
	private String indirizzo;
	@OneToMany(mappedBy="negozio")
	private List<Articolo> inNegozio;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public List<Articolo> getInNnegozio() {
		return inNegozio;
	}
	public void setInNnegozio(List<Articolo> inNnegozio) {
		this.inNegozio = inNnegozio;
	}
	@Override
	public boolean equals(Object o) {
		Negozio n=(Negozio)o;
		return this.getIndirizzo().equals(n.getIndirizzo());
	}
	@Override
	public int hashCode() {
		return this.getIndirizzo().hashCode();
	}
	
	
}
