package it.uniroma3.siw.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Articolo;
import it.uniroma3.siw.repository.ArticoloRepository;

@Component
public class ArticoloValidator implements Validator {

		@Autowired
		public ArticoloRepository articoloRepository;
		
		
		public void validate(Object o,Errors errors) {
			Articolo articolo=(Articolo)o;
			if(articolo.getNegozio()==null) {
				errors.reject("articolo.noNegozio");
			}
			else if(articolo.getNegozio().getId()==0){
				errors.reject("articolo.noNegozio");
			}
			
			if(articolo.getDescrizione()!=null && articolo.getPrezzo()!=0 
					&& articoloRepository.existsByDescrizioneAndPrezzo(articolo.getDescrizione(), articolo.getPrezzo())) {
				errors.reject("articolo.duplicate");
			}
				
		}
		
		public boolean supports(Class<?> aClass) {
			return Articolo.class.equals(aClass);
		}

}
